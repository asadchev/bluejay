Libint - a library for the evaluation of molecular integrals of many-body operators over Gaussian functions

- master status: [![Build Status](https://travis-ci.org/evaleev/libint.svg?branch=master)](https://travis-ci.org/evaleev/libint)
- project page: http://libint.valeyev.net/
- e-mail - libint@valeyev.net

See [the wiki](https://github.com/evaleev/libint/wiki) for installation and usage instructions.

Copyright (C) 2004-2018 Edward F. Valeev
