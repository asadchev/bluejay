#if HAVE_CONFIG_H
#   include "config.h"
#endif

#include "tcgmsgP.h"

long NODEID_(void)
{
    return (long) TCGMSG_nodeid;
}
