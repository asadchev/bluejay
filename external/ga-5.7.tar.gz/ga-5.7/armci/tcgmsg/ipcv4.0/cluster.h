/* $Header: /tmp/hpctools/ga/tcgmsg/ipcv4.0/cluster.h,v 1.4 1995-02-24 02:17:13 d3h325 Exp $ */

/*
  Define stubs for routines in cluster.c
*/

extern void PrintClusInfo();
extern void InitClusInfo();
extern void InitGlobal();
