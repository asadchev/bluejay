ARMCI_HOME = ../../../../src
ifndef TARGET
error:
    @echo "TARGET machine not defined"
    exit
endif
