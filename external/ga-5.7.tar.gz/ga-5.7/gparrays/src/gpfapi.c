#if HAVE_CONFIG_H
#   include "config.h"
#endif

#include "gp-papi.h"
#if ENABLE_PROFILING
#   include "gp-wapi.h"
#else
#   include "gp-wapidefs.h"
#endif
